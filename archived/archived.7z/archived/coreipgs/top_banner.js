<!-- Begin

// NOTE: If you use a ' add a slash before it like this \'

document.write('<TABLE cellpadding="0" cellspacing="0" border="0" width="100%"><tr><td width="900">');
document.write('<a href="index.html"><img src="picts/banner.jpg" HEIGHT="125" WIDTH="900" border="0"></a><br>');
document.write('</td><td background="picts/banner-background.jpg">');
document.write('&nbsp;<br>');
document.write('</td></tr><tr><td bgcolor="#7D8FB1" colspan="2" height="2">');
document.write('<img src="picts/spacer.gif" HEIGHT="2" WIDTH="10"><br>');
document.write('</td></tr></table>');

//  End -->