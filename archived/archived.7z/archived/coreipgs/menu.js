
<!-- Begin

// NOTE: If you use a ' add a slash before it like this \'

// NOTE: The following spacer "height=" locates the menu



document.write('<TABLE cellpadding="0" cellspacing="0" border="0" width="160">');
document.write('<tr><td>');

document.write('<img src="picts/menu-top.gif"><br>');


// NOTE: COPY AND PASTE THE NEXT 2 LINES TO MAKE A NEW LINK


document.write('</td></tr><tr><td align="left" valign="center" class="menulinks">');
document.write('<a href="services.htm">Our Services</a><br>');


document.write('</td></tr><tr><td align="left" valign="center" class="menulinks">');
document.write('<a href="caregivers.htm">Our Caregivers</a><br>');


document.write('</td></tr><tr><td align="left" valign="center" class="menulinks">');
document.write('<a href="interview.htm">Assessment Interview</a><br>');


document.write('</td></tr><tr><td align="left" valign="center" class="menulinks">');
document.write('<a href="employment.htm">Employment Opportunities</a><br>');


document.write('</td></tr><tr><td align="left" valign="center" class="menulinks">');
document.write('<a href="theseniorschoice.htm">The Senior\'s Choice</a><br>');


document.write('</td></tr><tr><td align="left" valign="center" class="menulinks">');
document.write('<a href="resources.htm">Resources</a><br>');



document.write('</td></tr><tr><td align="left" VALIGN="center">');
document.write('<img src="picts/spacer.gif" HEIGHT="10" WIDTH="10"><br>');
document.write('</td></tr></table>');
document.write('<!-- LINK TABLE-->');


//  End -->