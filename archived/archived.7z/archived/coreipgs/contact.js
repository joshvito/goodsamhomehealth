<!-- Start

// NOTE: If you use a ' add a slash before it like this \'

document.write('<span class="phonetitle">');

document.write(' Good Samaritan CareGivers');

document.write('</span><br>');

document.write('<span class="TABLE">The Williamsville Executive Center<br>5500 Main Street, Suite 109<br></span>');

document.write('<span class="TABLE">Williamsville, NY 14221<br></span>');

document.write('PHONE: <span class="phonetitle">(716) 204-0710<BR></span>');

document.write('FAX: &nbsp;&nbsp;<span class="phonetitle">(716) 568-2019<BR></span>');
document.write('<BR>E-mail us: ');

document.write(' <A HREF="mailto:info@goodsamaritancaregivers.com">info@goodsamaritancaregivers.com</a><br>');

//  End -->